JARVIS FKSB — Android starter project

এই প্রজেক্টে আছে:
- বাংলা/ইংরেজি voice recognition (ফোনের speech service-এর ওপর নির্ভরশীল)
- Text-to-speech
- Time/date
- YouTube, WhatsApp, Maps, Google search, Camera shortcuts
- Matrix-green style native Android screen

সীমাবদ্ধতা:
- এটি প্রথম starter version, পূর্ণ cloud AI assistant নয়।
- AI conversation যোগ করতে secure backend/API দরকার; API key কখনো APK/সর্বসাধারণের code-এ রাখবেন না।
- Android-এর permission ছাড়া Wi-Fi/mobile data toggling, lock/unlock, always-on microphone বা সব system controls করা যাবে না।
- এই পরিবেশে Android SDK/Gradle build setup নেই, তাই এখানে সরাসরি APK compile করা সম্ভব হয়নি।

Cloud build workflow: .github/workflows/build.yml
প্রজেক্ট GitHub-এ upload করলে Actions tab থেকে “Build JARVIS APK” workflow চালিয়ে artifact হিসেবে debug APK build করা যায়।
