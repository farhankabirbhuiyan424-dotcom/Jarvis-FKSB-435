package com.fksb.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val green = Color.rgb(0, 255, 120)
    private val bg = Color.rgb(4, 12, 9)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        if (SpeechRecognizer.isRecognitionAvailable(this)) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 22); setBackgroundColor(bg) }
        val title = TextView(this).apply { text = "J.A.R.V.I.S"; textSize = 30f; typeface = Typeface.MONOSPACE; setTextColor(green); gravity = Gravity.CENTER; setPadding(0, 8, 0, 4) }
        val subtitle = TextView(this).apply { text = "FKSB • PERSONAL AI ASSISTANT"; textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 22) }
        status = TextView(this).apply { text = "SYSTEM READY • TAP MIC TO SPEAK"; textSize = 12f; typeface = Typeface.MONOSPACE; setTextColor(green); gravity = Gravity.CENTER; setPadding(0, 12, 0, 12) }
        log = TextView(this).apply { text = "JARVIS: Hello. আমি প্রস্তুত। আমাকে বাংলা বা English-এ command দিন।\n\n"; textSize = 15f; typeface = Typeface.MONOSPACE; setTextColor(Color.WHITE); setPadding(12, 12, 12, 12) }
        val scroll = ScrollView(this).apply { addView(log) }
        input = EditText(this).apply { hint = "আপনার command লিখুন..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(true); setBackgroundColor(Color.rgb(15, 30, 22)) }
        val send = Button(this).apply { text = "SEND COMMAND"; setOnClickListener { val s=input.text.toString().trim(); if(s.isNotEmpty()){ input.setText(""); handle(s) } } }
        val mic = Button(this).apply { text = "🎙 SPEAK / কথা বলুন"; setOnClickListener { listen() } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(mic, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); addView(send, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        root.addView(title); root.addView(subtitle); root.addView(status); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(input); root.addView(row)
        setContentView(root)
    }

    override fun onInit(code: Int) { if (code == TextToSpeech.SUCCESS) { tts?.language = Locale("bn", "BD"); tts?.setSpeechRate(1.12f) } }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101); return }
        val r = recognizer ?: run { reply("আপনার ফোনে speech recognition service পাওয়া যাচ্ছে না।"); return }
        status.text = "LISTENING... / শুনছি"
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "LISTENING..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "PROCESSING..." }
            override fun onError(error: Int) { status.text = "READY • TAP MIC TO TRY AGAIN"; append("SYSTEM", "কথা বুঝতে পারিনি। আবার চেষ্টা করুন বা লিখে command দিন।") }
            override fun onResults(results: Bundle?) { val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); status.text = "COMMAND RECEIVED"; if (words != null) handle(words) }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD"); putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD"); putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS-কে command দিন / Speak to JARVIS") }
        try { r.startListening(i) } catch (_: Exception) { status.text = "READY"; reply("Microphone চালু করা যায়নি।") }
    }

    private fun handle(raw: String) {
        append("YOU", raw)
        val q = raw.lowercase(Locale.ROOT)
        when {
            q.contains("time") || q.contains("সময়") || q.contains("কটা বাজে") -> reply("এখন সময় ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())}।")
            q.contains("date") || q.contains("তারিখ") || q.contains("আজকে কি বার") -> reply("আজ ${SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("bn", "BD")).format(Date())}।")
            q.contains("youtube") || q.contains("ইউটিউব") -> openUrl("https://www.youtube.com", "YouTube খুলছি।")
            q.contains("whatsapp") || q.contains("হোয়াটসঅ্যাপ") -> openApp("com.whatsapp", "WhatsApp খুলছি।")
            q.contains("map") || q.contains("ম্যাপ") || q.contains("ম্যাপস") -> openUrl("https://maps.google.com", "Google Maps খুলছি।")
            q.contains("google") || q.startsWith("search ") || q.contains("খুঁজে দাও") || q.contains("সার্চ") -> { val term = raw.replace(Regex("(?i)google|search|সার্চ|খুঁজে দাও"), "").trim(); openUrl("https://www.google.com/search?q=" + Uri.encode(term.ifBlank { "Google" }), "Google search খুলছি।") }
            q.contains("open camera") || q.contains("ক্যামেরা") -> try { startActivity(Intent("android.media.action.IMAGE_CAPTURE")); reply("Camera খুলছি।") } catch (_: Exception) { reply("Camera চালু করা যায়নি।") }
            q.contains("hello") || q.contains("হ্যালো") || q.contains("হাই") -> reply("Hello! আমি JARVIS FKSB। বলুন, কীভাবে সাহায্য করতে পারি?")
            q.contains("who are you") || q.contains("তুমি কে") -> reply("আমি আপনার JARVIS assistant-এর প্রথম Android version। এখন basic commands চালাতে পারি; advanced AI chat যোগ করতে secure online AI service লাগবে।")
            q.contains("thank") || q.contains("ধন্যবাদ") -> reply("আপনাকে স্বাগতম! আমি সাহায্য করতে প্রস্তুত।")
            q.contains("help") || q.contains("সাহায্য") || q.contains("কি করতে পারো") -> reply("আমি সময়-তারিখ বলতে, YouTube, WhatsApp, Maps, Google search এবং Camera খুলতে পারি। আরও command ধাপে ধাপে যোগ করা যাবে।")
            else -> reply("আপনার কথা শুনেছি: $raw। এই version-এ এখনো পূর্ণ AI brain যুক্ত নেই। সাধারণ command দিন, অথবা AI chat যুক্ত করতে online service configure করতে হবে।")
        }
    }
    private fun reply(s: String) { append("JARVIS", s); tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }
    private fun append(who: String, s: String) { log.append("$who: $s\n\n") }
    private fun openUrl(url: String, msg: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); reply(msg) } catch (_: Exception) { reply("এটা খোলা যায়নি।") } }
    private fun openApp(pkg: String, msg: String) { val i = packageManager.getLaunchIntentForPackage(pkg); if (i != null) { startActivity(i); reply(msg) } else reply("অ্যাপটি ইনস্টল করা নেই বা খোলা যাচ্ছে না।") }
    override fun onDestroy() { recognizer?.destroy(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
